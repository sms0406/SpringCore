package com.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("emp")

public class Employee {
	@Value("1001")
	private Integer empId;
	@Value("raj")
	private String empName;
	@Autowired
	private Department dept;
	
	/*public Employee(Department dept) {
		this.dept=dept;
	}*/
	/*public Employee(int eid, String ename) {
		empId=eid;
		empName=ename;
		
	}*/
	public Integer getEmpId() {
		return empId;
	}
	public void setEmpId(Integer empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public Department getDept() {
		return dept;
	}
	public void setDept(Department dept) {
		this.dept = dept;
	}
	

}

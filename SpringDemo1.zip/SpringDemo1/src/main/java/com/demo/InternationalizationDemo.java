package com.demo;

import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.MessageSource;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class InternationalizationDemo {
	 /* @Autowired
      private MessageSource messageSource;*/
	public static void main(String[] args) {
			ApplicationContext context = new ClassPathXmlApplicationContext("inter.xml");
			Locale locale = new Locale("fr");
			String msg = context.getMessage("welcome",null,locale);
				System.out.println("message is "+msg);	
			 
	}

}

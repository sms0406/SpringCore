package com.demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Starter {
	
	public static void main(String[] args) {
		//Employee e = new Employee();
		/*ClassPathResource res = new ClassPathResource("config.xml");
		BeanFactory factory = new XmlBeanFactory(res);*/
		//ApplicationContext context = new ClassPathXmlApplicationContext("config_scope.xml");
		/*Employee e=(Employee)context.getBean("emp");
		System.out.println(e.getEmpName());
		System.out.println(e.getEmpId());
		System.out.println(e.getDept().getDeptName());*/
		
		/*Login l = (Login)context.getBean("login");
		System.out.println(l.getId());
		System.out.println(l.getUser().getUserName());
		*/
		/*ApplicationContext context = new AnnotationConfigApplicationContext(Config.class);
		Customer c =(Customer) context.getBean("customer");
		System.out.println(c.getCustomerName());
		System.out.println(c.getAddress().getCity()); */
		ApplicationContext context = new ClassPathXmlApplicationContext("config_scope.xml");
		
		Login l = (Login)context.getBean("login");
		System.out.println(l.getId());
	}

}

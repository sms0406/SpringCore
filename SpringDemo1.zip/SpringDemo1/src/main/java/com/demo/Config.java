package com.demo;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.Environment;

@Configuration

@PropertySource("classpath:login.properties")
public class Config {
	
	/*@Bean(name="cust")
	public Customer customer() {
		Customer c = new Customer();
		c.setCustomerId(101);
		c.setCustomerName("smi");
		c.setAddress(address());
		return c;
	}
	@Bean
	public Address address() {
		Address a = new Address();
		a.setCity("chennai");
		return a;
	}
*/
	@Autowired
	Environment env;
	
	@Bean
	public Login login() {
		Login l = new Login();
		l.setId(Integer.parseInt(env.getProperty("id")));
		return l;
	}
	
	 @Bean
     public static PropertySourcesPlaceholderConfigurer getPropertySourcePlaceholderConfig() {
         PropertySourcesPlaceholderConfigurer ret = new PropertySourcesPlaceholderConfigurer();
         return ret;
     }
     
}
